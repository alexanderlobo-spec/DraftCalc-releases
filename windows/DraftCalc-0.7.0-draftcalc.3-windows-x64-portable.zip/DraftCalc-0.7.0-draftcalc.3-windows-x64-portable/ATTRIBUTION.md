# Asset attribution

Every non-code asset in this repository (images, icons, fonts, example files, presets) is listed here with its author, source and licence. `cargo xtask assets` (part of `cargo xtask ci`) fails if an asset file is missing from this table.

**Policy (mandatory):** DraftCalc (like GridCraft) contains **no Microsoft, Adobe, Avid or Autodesk iconography, images, artwork, fonts, templates, themes, table styles or sample files**. Every asset is original work by GridCraft contributors or third-party material under an open licence (OSI open source, public domain / CC0, or Creative Commons that allows redistribution). Screenshots of Microsoft software are never committed. Font files are not added here: shared fonts live in [storytold/craft-fonts](https://github.com/storytold/craft-fonts), an optional build input (`CRAFT_FONTS_DIR`). The one exception is the ArtCraft brand files in `docs/brand/`: ArtCraft trademarks, not open source, used under `docs/brand/LICENSE-brand.txt` (kept only because the upstream README copy in `docs/GRIDCRAFT-UPSTREAM.md` refers to them).

Generated-in-code art is original and has no file to list: the UI icon set (`crates/ui-egui/src/icons.rs` e `icons_line.rs`, incluindo os glifos originais Manzana Line do DraftWord e os desenhos de planilha do DraftCalc), themes (`crates/engine/src/cmd/view.rs`), cell styles (`crates/engine/src/cmd/format.rs`), table styles (`crates/engine/src/tables.rs`), chart palettes and the sample workbooks (`crates/engine/src/sample.rs`).

| Asset | Author | Source | Licence | Notes |
|---|---|---|---|---|
| `docs/brand/artcraft-logo.svg` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms (`docs/brand/LICENSE-brand.txt`) | Trademark, not open source |
| `docs/brand/artcraft-logo.png` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-logo-white.svg` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-logo-white.png` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-mark.svg` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-mark.png` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-mark-black.svg` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/artcraft-mark-black.png` | ArtCraft Team | craftrules `assets/brand/` | ArtCraft brand terms | Trademark |
| `docs/brand/LICENSE-brand.txt` | (licence text) | craftrules | — | |
| `assets/draftcalc/hicolor/16x16/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/24x24/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/32x32/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/48x48/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/64x64/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/128x128/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/256x256/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `assets/draftcalc/hicolor/512x512/apps/com.alexanderlobo.draftcalc.png` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | redimensionado de `assets/draftcalc/icon-1024.png` (ícone definitivo, DC-000) por `packaging/icons.sh` | uso privado do autor | Tema hicolor do Linux |
| `docs/images/draftcalc/aparencia-manzana-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Manzana, modo claro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/aparencia-manzana-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Manzana, modo escuro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/aparencia-ceu-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Céu, modo claro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/aparencia-ceu-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Céu, modo escuro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/aparencia-grafite-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Grafite, modo claro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/aparencia-grafite-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`crates/ui-egui/examples/snapshot.rs`) com a pasta de exemplo original, identidade Grafite, modo escuro | MIT OR Apache-2.0 | DC-002; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-manzana-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Manzana, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-manzana-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Manzana, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-ceu-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Céu, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-ceu-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Céu, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-grafite-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Grafite, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/linha-grafite-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: cabeçalho Linha e faixa única, identidade Grafite, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-manzana-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Manzana, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-manzana-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Manzana, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-ceu-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Céu, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-ceu-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Céu, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-grafite-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Grafite, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/biblioteca-grafite-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: Biblioteca, identidade Grafite, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-manzana-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Manzana, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-manzana-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Manzana, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-ceu-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Céu, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-ceu-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Céu, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-grafite-claro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Grafite, modo claro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/draftcalc/trilho-grafite-escuro.png` | Alexander Lobo, com Claude | captura do DraftCalc renderizado sem janela (`snapshot.rs`) com a pasta de exemplo original: variante Trilho, identidade Grafite, modo escuro | MIT OR Apache-2.0 | DC-004; nenhum conteúdo de terceiros |
| `docs/images/hero-sales.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/budget.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/grades-formulas.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/dark-insert.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/pivot.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/format-chart.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |
| `docs/images/page-break.png` | GridCraft contributors | screenshot of GridCraft rendered offscreen (`crates/ui-egui/examples/snapshot.rs`) showing an original sample workbook | MIT OR Apache-2.0 | README screenshot; no third-party content |

## Referências do DraftWord (só leitura, fora do build)

| Arquivo | Autor | Origem | Licença |
|---|---|---|---|
| `docs/referencia-draftword/assets/DraftWord.svg` | Alexander Lobo, com Claude | desenho original do DraftWord (DW-018), copiado como referência da família visual | uso privado do autor |
| `assets/draftcalc/icon-1024.png`, `assets/draftcalc/icon-512.png`, `assets/draftcalc/DraftCalc.icns`, `assets/draftcalc/DraftCalc.ico` | Alexander Lobo, com IA de imagem a partir do briefing `docs/LOGO-DRAFTCALC.md` | desenho original da família "Página em D vazado" (DC-000) | uso privado do autor |

## Capturas locais DC-009 — 15/out/2026

| Arquivo | Autor | Origem | Licença | Observações |
|---|---|---|---|---|
| `docs/images/draftcalc/dc-009-completa-claro.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot, dados sintéticos originais | MIT OR Apache-2.0 | faixa completa clara; DC-009 |
| `docs/images/draftcalc/dc-009-inserir-escuro.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot, dados sintéticos originais | MIT OR Apache-2.0 | aba Inserir escura; DC-009 |
| `docs/images/draftcalc/dc-009-painel.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot, dados sintéticos originais | MIT OR Apache-2.0 | painel de comentários; DC-009 |


## Capturas locais DC-011 — 15/out/2026

| Arquivo | Autor | Origem | Licença | Observações |
|---|---|---|---|---|
| `docs/images/draftcalc/dc-011-localizar-escuro.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot | MIT OR Apache-2.0 | janela mínima, campos alinhados |
| `docs/images/draftcalc/dc-011-formatar-celulas.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot | MIT OR Apache-2.0 | margens e ações, códigos com rolagem |
| `docs/images/draftcalc/dc-011-configurar-pagina.png` | Alexander Lobo, com Codex | captura local do DraftCalc pelo exemplo snapshot | MIT OR Apache-2.0 | alinhamento dos campos numéricos |
